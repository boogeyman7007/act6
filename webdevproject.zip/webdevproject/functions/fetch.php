<?php

    // fetching data
    $query = "Select * FROM tblsubject";
    $result = mysqli_query($dbc, $query); // using mysqli_query

?>